function openTab(evt, tabName) {
  document.querySelectorAll('.tabcontent').forEach(c => c.style.display = 'none');
  document.querySelectorAll('.tab button').forEach(b => b.classList.remove('active'));
  document.getElementById(tabName).style.display = 'block';
  evt.currentTarget.classList.add('active');
}

function navigate(select) {
  const value = select.value;
  if (value !== '#') window.location.href = value;
}

function speakText(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = /[\u0600-\u06FF]/.test(text) ? 'ur-PK' : 'en-US';
  speechSynthesis.speak(utterance);
}
function playAudio(id) {
  const audio = new Audio(`audio/${id}.mp3`);
  audio.play();
}
function openTab(evt, tabName) {
  document.querySelectorAll('.tabcontent').forEach(c => {
    c.classList.remove('visible');
    c.style.display = 'none';
  });

  document.querySelectorAll('.tab button').forEach(b => b.classList.remove('active'));

  const activeTab = document.getElementById(tabName);
  activeTab.style.display = 'block';
  setTimeout(() => activeTab.classList.add('visible'), 10);
  evt.currentTarget.classList.add('active');
}
function navigate(select) {
  const value = select.value;
  if (value && value !== '#') {
    if (confirm("Proceed to this page?")) {
      window.location.href = value;
    }
  }
}
function speakText(text, options = {}) {
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = /[\u0600-\u06FF]/.test(text) ? 'ur-PK' : 'en-US';
  utterance.pitch = options.pitch || 1;
  utterance.rate = options.rate || 1;
  speechSynthesis.speak(utterance);
}
function playAudio(id) {
  const audio = new Audio(`audio/${id}.mp3`);
  audio.oncanplaythrough = () => audio.play();
  audio.onerror = () => alert('Audio file not found.');
}

